# Title: C4T3 - Evaluate Techniques for Wifi Locationing

#Updated:  10/29/2022


###############
# Project Notes
###############


# Clear console: CTRL + L


###############
# Housekeeping
###############


###############
# Load packages
###############
install.packages("Rtools")
install.packages("caret")
install.packages("corrplot")
install.packages("readr")
install.packages("mlbench")
install.packages("doParallel")
install.packages("reshape2")
install.packages("dplyr")
install.packages("arules")
install.packages("arulesViz")
install.packages("RMariaDB")
install.packages("lubridate")
install.packages("plotly")
install.packages("ggfortify")
install.packages("forecast")
install.packages("e1071")
install.packages("class")
install.packages("ISLR")
install.packages("kknn")
install.packages("rpart")
library(caret)
library(corrplot)
library(readr)
library(mlbench)
library(doParallel)
library(e1071)
library(gbm)
library(ggplot2)
library(writexl)
library(reshape2)
library(dplyr)
library(arules)
library(arulesViz)
library(RMariaDB)
library(lubridate)
library(plotly)
library(ggfortify)
library(forecast) 
library(e1071)
library(class)
library(kknn)
library(rpart)
#library(ISLR)

#update.packages(checkBuilt = TRUE)

# Clear objects if necessary
rm(list = ls())

# get working directory
getwd()

# set working directory 
setwd("C:/Users/giniewic/OneDrive - HP Inc/Documents/Personal/UT Data Analytics Cert/Course 4/C4T3")

# see files in working directory
dir()

#####################
# Parallel Processing
#####################


####################
# Import data
####################

##-- Load the dataset
dataTrainOOB <- read.csv("trainingData.csv")
dataValidOOB <- read.csv("validationData.csv")
str(dataTrainOOB)
str(dataValidOOB)



######################
# Save datasets
######################


##################
# Evaluate data
##################

# View first/last obs/rows
head(dataTrainOOB)
tail(dataTrainOOB)
anyNA(dataTrainOOB)
anyDuplicated(dataTrainOOB)
summary(dataTrainOOB)


#############
# Preprocess
#############

# ---- Train Dataset Preprocessing ---- #

# Combine location into unique identifier 
dataTrainOOB$Location <- paste(dataTrainOOB$BUILDINGID,
                               dataTrainOOB$FLOOR,
                               dataTrainOOB$SPACEID,
                               dataTrainOOB$RELATIVEPOSITION, sep=".")

# Location = Building.Floor.SpaceID.Relative Position


# view column names to determine which ones to keep in subset
colnames(dataTrainOOB)
# WAP = [1:520]
# Location = [530]

# Create subset of data for only one building
# Count rows in each building
nrow(subset(dataTrainOOB, BUILDINGID == "0"))
nrow(subset(dataTrainOOB, BUILDINGID == "1"))
nrow(subset(dataTrainOOB, BUILDINGID == "2"))

# Building 0 - 5249 rows
# Building 1 - 5196 rows
# Building 2 - 9492 rows



# Create subset for Building 1
dataTrainB1 <- subset(dataTrainOOB, BUILDINGID == "1")
# Only keep WAP and location columns
dataTrainB1 <- dataTrainB1[c(1:520, 530)]

# Check subset
colnames(dataTrainB1)
head(dataTrainB1)
nrow(dataTrainB1)



# Convert new location column to factor
dataTrainB1$Location <- as.factor(dataTrainB1$Location)
str(dataTrainB1$Location)

# Remove WAPs with zero variance

# table to see features with zero variance 
nzvMetrics1 <- nearZeroVar(dataTrainB1, saveMetrics = TRUE)

# create index to easily remove features 
nzv1 <- which(nzvMetrics1$zeroVar == TRUE) 

dataTrainB1NZV <- dataTrainB1[,-nzv1]

#check that it worked
colnames(dataTrainB1NZV)


typeof(dataTrainB1NZV$Location)
# Convert  location column to factor
dataTrainB1NZV$Location <- as.factor(dataTrainB1NZV$Location)
str(dataTrainB1NZV$Location)


# ---- Validation Dataset Preprocessing ---- #
colnames(dataValidOOB)

# Combine location into unique identifier 
dataValidOOB$Location <- paste(dataValidOOB$BUILDINGID,
                               dataValidOOB$FLOOR,
                               dataValidOOB$SPACEID,
                               dataValidOOB$RELATIVEPOSITION, sep=".")
table(dataValidOOB$Location)

# Convert new location column to factor
dataValidOOB$Location <- as.factor(dataValidOOB$Location)
str(dataValidOOB$Location)

# Only keep WAP and location columns
dataValidOOB <- dataValidOOB[c(1:520, 530)]

# Remove same WAPs from training data
dataValidNZV <- dataValidOOB[,-nzv1]

#check that it worked
colnames(dataValidNZV)

typeof(dataValidNZV$Location)
# Convert  location column to factor
dataValidNZV$Location <- as.factor(dataValidNZV$Location)
str(dataValidNZV$Location)


#####################
# EDA/Visualizations
#####################


#######################
# Feature selection
#######################


#######################
# Correlation analysis
#######################

# for regression problems, the below rules apply.
# 1) compare each IV to the DV, if cor > 0.95, remove
# 2) compare each pair of IVs, if cor > 0.90, remove the
#    IV that has the lowest cor to the DV. (see code
#    below for setting a threshold to automatically select
#    IVs that are highly correlated)

# for classification problems, the below rule applies.
# 1) compare each pair of IVs, if cor > 0.90, remove one
#    of the IVs. (see code below to do this programmatically)


corrAll <- cor(dataTrainB1NZV[,1:207])
corrhigh <- findCorrelation(corrAll, cutoff=0.9) 
corrhigh
colnames(dataTrainB1NZV[corrhigh])

# "WAP116" "WAP126" "WAP137" "WAP167" "WAP177" "WAP187" "WAP113" "WAP129" "WAP134" "WAP208" "WAP362"

# WAP116 & WAP115; WAP126 & WAP125; WAP 137 & WAP 136
# cor(dataTrainB1NZV$WAP137, dataTrainB1NZV[,1:207])

# Remove highly correlated variables 
dataTrainB1NZV <- dataTrainB1NZV[,-corrhigh]
dataValidNZV <- dataValidNZV[,-corrhigh]

# Check again that there are no more highly correlated variables
corrAll2 <- cor(dataTrainB1NZV[,1:196])
corrhigh2 <- findCorrelation(corrAll2, cutoff=0.9) 
corrhigh2
colnames(dataTrainB1NZV[corrhigh2])

colnames(dataTrainB1NZV)

# plot correlation matrix
corrplot(corrAll, method = "circle", main="Correlation of Sample Data - Building 1")
corrplot(corrAll, order = "hclust", main="Correlation of Sample Data - Building 1") # sorts based on level of collinearity



##################
# Train/test sets
##################
# 75% will be for training; 25% for testing 
# Set seed
set.seed(123)
inTraining <- createDataPartition(as.factor(dataTrainB1NZV$Location), p=0.75, list=FALSE)
dataTrain <- dataTrainB1NZV[inTraining,]
dataTest <- dataTrainB1NZV[-inTraining,]

#verify number of observations
nrow(dataTrain) #3964
nrow(dataTest) #1232

################
# Train control
################

# set cross validation -- splits into 10 for cross-validation
fitControl <- trainControl(method="repeatedcv", number=10, repeats=1)

###############
# Train models
###############

#modelLookup("knn")
#names(getModelInfo())

# ----- C5.0 Model ----- #

set.seed(123)
C50fit <- train(Location~., data=dataTrain, method="C5.0", importance = T, trControl=fitControl)
C50fit
#model  winnow  trials  Accuracy   Kappa    
#rules  FALSE    1      0.6880209  0.6861034
#rules  FALSE   10      0.7860137  0.7847060
#rules  FALSE   20      0.7920555  0.7907883
#rules   TRUE    1      0.6813234  0.6793765
#rules   TRUE   10      0.7852001  0.7838958
#rules   TRUE   20      0.7908807  0.7896121
#tree   FALSE    1      0.6820550  0.6801273
#tree   FALSE   10      0.7873187  0.7859934
#tree   FALSE   20      0.8016946  0.8004652   **** HIGHEST ACC/KAPPA ****
#tree    TRUE    1      0.6750610  0.6730983
#tree    TRUE   10      0.7782749  0.7768965
#tree    TRUE   20      0.7875654  0.7862477

plot(C50fit)
varImp(C50fit)

#Overall
#WAP181  100.00
#WAP179  100.00
#WAP130  100.00
#WAP104  100.00
#WAP105  100.00
#WAP124  100.00
#WAP140  100.00
#WAP149   99.17
#WAP114   98.69
#WAP120   94.32
#WAP136   93.09
#WAP119   91.27
#WAP164   79.69
#WAP089   79.31
#WAP178   77.95
#WAP261   77.07
#WAP147   70.43
#WAP107   64.43
#WAP176   62.56
#WAP255   61.38


# ----- C5.0 Tree Model ----- #

set.seed(123)
C50Treefit <- train(Location~., data=dataTrain, method="C5.0Tree", importance = T, trControl=fitControl)
C50Treefit

#Accuracy   Kappa    
#0.682055  0.6801273


# ----- K-Nearest Neighbors Model ----- #
set.seed(123)
knnfit <- train(Location~., data=dataTrain, method="knn", trControl=fitControl, preProcess = c("center", "scale"), tuneLength = 10)
knnfit

#k   Accuracy   Kappa    
#5  0.6127324  0.6103866   **** HIGHEST ACC/KAPPA ****
#7  0.5817665  0.5792163
#9  0.5586942  0.5559866
#11  0.5441059  0.5412729
#13  0.5181027  0.5151033
#15  0.4926969  0.4895066
#17  0.4869415  0.4836854
#19  0.4716107  0.4682512
#21  0.4562211  0.4527455
#23  0.4443678  0.4408028


# ----- Random Forest Model ----- #
set.seed(123)
rffit <- train(Location~., data=dataTrain, method="rf", importance = T, trControl=fitControl)
rffit

#mtry  Accuracy   Kappa    
#2   0.2189325  0.2097881
#99   0.8498778  0.8489517    **** HIGHEST ACC/KAPPA ****
#196   0.8346975  0.8336765

#Accuracy was used to select the optimal model using the largest value.
#The final value used for the model was mtry = 99.


# ----- CART Model ----- #
set.seed(123)
cartfit <- rpart(Location~., method="class", data=dataTrain)
cartfit
summary(cartfit)
printcp(cartfit)


# ----- Naive-Bayes Model ----- #
set.seed(123)
nbfit <- train(Location~., data=dataTrain, method="naive_bayes", importance = T, trControl=fitControl)
nbfit

#usekernel  Accuracy   Kappa    
#FALSE      0.1537186  0.1514279
#TRUE      0.4079939  0.4020255

############################
# Predict testSet/validation
############################

# ----- predict with C5.0 Model ----- #
c50Predict <- predict(C50fit, dataTest)
postResample(c50Predict, dataTest$Location)

#Accuracy     Kappa 
#0.7857143 0.7844001 


# ----- predict with C5.0 TreeModel ----- #
c50TreePredict <- predict(C50Treefit, dataTest)
postResample(c50TreePredict, dataTest$Location)

#Accuracy     Kappa 
#0.7086039 0.7067966 


# ----- predict with K-Nearest Neighbors Model ----- #
knnPredict <- predict(knnfit, dataTest)
postResample(knnPredict, dataTest$Location)

#Accuracy     Kappa 
#0.6250000 0.6226404 


# ----- predict with Random Forest Model ----- #
rfPredict <- predict(rffit, dataTest)
postResample(rfPredict, dataTest$Location)

#Accuracy     Kappa 
#0.8498377 0.8489023 


# ----- predict with CART Model ----- #
cartPredict <- predict(cartfit, dataTest)
postResample(cartPredict, dataTest$Location)

#Accuracy    Kappa 
#NA       NA 

# ----- predict with Naive-Bayes Model ----- #
nbPredict <- predict(nbfit, dataTest)
postResample(nbPredict, dataTest$Location)

#Accuracy     Kappa 
#0.4350649 0.4291839 



##################
# Model selection
##################

# Use Resample to compare models (excluding CART and NB since they were Na and lowest accuracy)
ModelData <- resamples(list(C50 = C50fit, C50Tree = C50Treefit, KNN = knnfit, RF = rffit))
summary(ModelData)

#Accuracy 
#             Min.   1st Qu.    Median      Mean   3rd Qu.      Max. NA's
#C50     0.7659033 0.7917411 0.8004212 0.8016946 0.8152958 0.8260870    0
#C50Tree 0.6545455 0.6717655 0.6794220 0.6820550 0.6926605 0.7128463    0
#KNN     0.5793451 0.5950809 0.6123320 0.6127324 0.6330996 0.6412214    0
#RF      0.8346056 0.8412601 0.8472119 0.8498778 0.8560687 0.8797954    0

#Kappa 
#             Min.   1st Qu.    Median      Mean   3rd Qu.      Max. NA's
#C50     0.7644928 0.7904463 0.7991924 0.8004652 0.8141328 0.8249857    0
#C50Tree 0.6524445 0.6697468 0.6775295 0.6801273 0.6907734 0.7111032    0
#KNN     0.5769130 0.5926349 0.6099645 0.6103866 0.6308699 0.6390950    0
#RF      0.8335874 0.8403011 0.8462554 0.8489517 0.8552014 0.8790509    0

# Create new dataset to plot the mean accuracy & kappa scores
modelName <- c('C5.0', 'C5.0 Tree', 'K-Nearest Neighbor', 'Random Forest')
accuracy <- c(0.8016946, 0.6820550, 0.6127324, 0.8498778)
kappa <- c(0.8004652, 0.6801273, 0.6103866, 0.8489517)
modelPlot <- data.frame(modelName, accuracy, kappa)

plot(modelPlot$accuracy, modelPlot$kappa)

ggplot(modelPlot, aes(x=accuracy, y=kappa, color=modelName)) +
  geom_point(size=6) +
  ggtitle("Accuracy & Kappa of each Model") +
  theme(plot.title = element_text(hjust=0.5), legend.position = "top", legend.title=element_blank())

#--- Random Forest is the best model since it has the highest Accuracy and Kappa---#


################################################
# Use Model with Validation Dataset
################################################

validPred <- predict(rffit, dataValidNZV)
head(validPred)
validPred

str(validPred)


